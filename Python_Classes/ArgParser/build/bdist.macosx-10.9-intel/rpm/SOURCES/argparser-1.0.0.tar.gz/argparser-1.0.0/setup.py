from distutils.core import setup
setup(name='argparser',
      version='1.0.0',
      packages=['argparser'],
      )
