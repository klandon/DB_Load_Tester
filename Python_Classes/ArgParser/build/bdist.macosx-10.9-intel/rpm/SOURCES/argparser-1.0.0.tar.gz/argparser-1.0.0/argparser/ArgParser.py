import sys  


class ArgParser:
    ParsedArgs = {}
           
    def __init__(self,SystemArgs):
        for i in range(len(sys.argv)):
            if i != 0:
                k,v = str(sys.argv[i]).split("=")
                self.ParsedArgs[k] = v
            
            
            
 
    